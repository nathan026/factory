Synthetic input for the offline release fixture.
